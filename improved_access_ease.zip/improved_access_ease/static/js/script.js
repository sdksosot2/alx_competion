// General JS for the scaffold. Add your custom JS here.
console.log('AccessEase scaffold loaded');
